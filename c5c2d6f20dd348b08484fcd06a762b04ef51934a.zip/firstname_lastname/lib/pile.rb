class Pile
  def initialize(cards)
  end

  # return the top (last) card and remove it from pile
  def take_card
  end

  # returns true if the pile is empty
  def empty?
  end

  # add cards to the bottom (beginning) of pile
  def add_cards(new_cards)
  end
end
