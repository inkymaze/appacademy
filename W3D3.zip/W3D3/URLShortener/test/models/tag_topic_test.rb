require 'test_helper'

class TagTopicTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
